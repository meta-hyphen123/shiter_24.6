__creator__ = "O.Koleda"
__maintainer__ = "mIcHyAmRaNe"
__version__ = "1.0.1"
