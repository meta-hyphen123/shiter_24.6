def list1():
    ls1 = ['  [0]-About/Help','  [1]-PortScanner','  [2]-E-Mail','  [3]-Servers','  [4]-Request Test','  [5]-Web Analysis'
        ,'  [6]-Stress Testing','  [7]-PassWord','  [8]-A-xex Console','  [99]-Exit']
    for frag in ls1:
        print(frag)

def portscanner():
    ls2 = ['  [1]-Principal Ports','  [2]-Big Range','  [3]-Scans Specific Ports','  [00]-Return']
    for frag in ls2:
        print(frag)

def mail():
    ls3 = ['  [1]-Send an E-mal message','  [00]-Return']
    for frag in ls3:
        print(frag)

def server():
    ls4 = ['  [1]-S-FTP server','  [2]-S-HTTP server','  [00]-Return']
    for frag in ls4:
        print(frag)

def VulnWeb():
    ls5 = ['  [1]-Dns Finder','  [2]-Directory Brute','  [3]-Spider','  [4]-SQLI Scan','  [5]-InfoGet Domain Scan','  [6]-InfoGet IP Scan','  [7]-XSS URL Tester','  [00]-Return']
    for frag in ls5:
        print(frag)

def strss():
    ls6 = ['  [1]-Slowloris','  [2]-UDP Flood','  [00]-Return']
    for frag in ls6:
        print(frag)
def psstools():
    ls7 = ['  [1]-Pass Generator','  [2]-Hash MD5 BruteForce Random','  [3]-Hash MD5 BruteForce','  [00]-Return']
    for frag in ls7:
        print (frag)
def console():
    ls8 = ['  [1]-Shell RSP','  [2]-Create RSP','  [3]-Bind TCP','  [4]-Bind UDP','  [5]-Python Reverse Shell','  [00]-Return']
    for frag in ls8:
        print(frag)
