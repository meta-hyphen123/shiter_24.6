def logo():
    print('     __                   ___             ')
    print('    /  \        \   /   /     \   \   /   ')
    print('   /____\   ___  \ /   | ____ /    \ /    ')
    print('  /      \       / \   |           / \    ')
    print(' /        \     /   \   \_____/   /   \   ')
    print('\033[42;1;33m' + '             A-xex 1.4 is up              ' + '\033[0;0m')
    print('\033[34m', 'Author not responsible for malicious use!', '\033[0;0m')
