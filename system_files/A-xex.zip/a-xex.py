#by farinap5 with love.
from mods import a_main
#starter
a_main.a_main()
