<h1 align="center">A-xex</h1>
<p align="center">This project is part of a school work focusing on network security.</p>
<p align="center">Author not responsable for malicious use.</p>
<p align="center">The project is always updating</p>
<p align="center"> 
   <img src="https://img.shields.io/badge/language-python-blue.svg">
</p>

***

# About A-xex Framework

```
A-xex is a simple and intuitive tool, it joins many important tools 
that can help in a hack action. The goal is to provide a simple, 
clear and organized interface but much usual.
```

---

## Simple and Clear UX/UI.

```
A-xex Framework has a simple and clear interface. 
It is easy to understand an it will be easier for 
you to master the A-xex Framework.
```
## Tool Map
```
A-xexF> python3 a-xex.py
     __                   ___             
    /  \        \   /   /     \   \   /   
   /____\   ___  \ /   | ____ /    \ /    
  /      \       / \   |           / \    
 /        \     /   \   \_____/   /   \   
             A-xex 1.4 is up              
 Author not responsible for malicious use! 
  Host Name:   Linux  kali  5.7.0-kali1-amd64 
  IP Address:  127.0.1.1 
  [OK]-Internet
  [OK]-Version.

  ├──[0]-About/Help
  │
  ├──[1]-PortScanner
  │   ├──[1]-Principal Ports
  │   ├──[2]-Big Range
  │   ├──[3]-Scans Specific Ports
  │   └──[00]-Return
  │
  ├──[2]-E-Mail
  │   ├──[1]-Send an E-mal message
  │   └──[00]-Return
  │
  ├──[3]-Servers
  │   ├──[1]-S-FTP server
  │   ├──[2]-S-HTTP server
  │   └──[00]-Return
  │
  ├──[4]-Request Test
  │
  ├──[5]-Web Analysis
  │   ├──[1]-Dns Finder
  │   ├──[2]-Directory Brute
  │   ├──[3]-Spider
  │   ├──[4]-SQLI Scan
  │   ├──[5]-InfoGet Domain Scan
  │   ├──[6]-InfoGet IP Scan
  │   ├──[7]-XSS URL Tester
  │   └──[00]-Return
  │
  ├──[6]-Stress Testing
  │   ├──[1]-Slowloris
  │   ├──[2]-UDP Flood
  │   └──[00]-Return
  │
  ├──[7]-PassWord
  │   ├──[1]-Pass Generator
  │   ├──[2]-Hash MD5 BruteForce Random
  │   ├──[3]-Hash MD5 BruteForce
  │   └──[00]-Return
  │
  ├──[8]-A-xex Console
  │   ├──[1]-Shell RSP
  │   ├──[2]-Create RSP
  │   ├──[3]-Bind TCP
  │   ├──[4]-Bind UDP
  │   ├──[5]-Python Reverse Shell
  │   └──[00]-Return
  │
  └──[99]-Exit

  >> 


```

## Port Scanner

```
Make many types of scans having IPs and domais 
as target as also in the local network. 
```
## Admin Panel, Directories and DNS Finder

```
Can be eazy to find directories vulnerable directories with a large WordList.
Dns and admin panel finder also have dedicated word lists.
```
## Servers

```
You can create easily some types of servers 
whithout prior knowledge.
```

## Web Analysis

```
Maybe the most desenvolved and important module.
the user can concentrate a lot of information about target, 
spiders functions and ip recognition are embbed also.
```

## Stress Testing

```
Test if any target is able to hold a heavy DOS attack.
```

## A-xex Console

```
Build in seconds a powerful shells reverse payload 
and a listener to receive de the information from the target, 
localy and external networks.
```

---

## Downloads and run

> git clone https://github.com/farinap5/A-xex.git

> cd A-xex

> python3 check_dependencies.py

> python3 a-xex.py

---

## A-xex Framework Disclaimer

```
Usage of the A-xex Framework for attack targets without prior mutual consent is illegal. 
It is the end user's responsability to obey all applicable local, state, federal and international laws. 
Developer assume no liability and not responsible for any misuse or damage caused by this program.
```
